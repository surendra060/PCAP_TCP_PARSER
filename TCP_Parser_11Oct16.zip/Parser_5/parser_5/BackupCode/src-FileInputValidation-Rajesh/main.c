#include <stdio.h>
#include <memory.h>

#define MAX_PCAP_FILE_SIZE 65536  //65536 BYTE
#define ETHERNET 0x01

//int ExtractMACAddress();
//int CheckEthernetAddress();
int CheckFileLength();
int CheckFrameLength();
int CheckLinkLayerProtocol();
int CheckMagicNumber();
int CheckVersionNumber();

int FileHeaderLength = 24;

int FrameHeaderLength = 16;

int FlagFileOpen,FlagMagicNumber;
unsigned char FileHeader[100],FrameHeader[100];
unsigned char MagicNumberLittleEndian[4] = {0xd4,0xc3,0xb2,0xa1};
unsigned char MagicNumberBigEndian[4] = {0xa1,0xb2,0xc3,0xd4};
int FlagBigEndian,FlagLittleEndian;
int MajorVersion,MinorVersion,FileLength;
int FrameLength1,FrameLength2,FrameLength;
int Protocol,Frame_Protocol;
//unsigned char SourceMACAddress[6],DestinationMACAddress[6];
FILE *fp=NULL;
unsigned char FrameData[MAX_PCAP_FILE_SIZE];


int main(int argc, char *argv[])
{

    int i;
    unsigned char ch;

    memset(FrameData,0xFF,sizeof(FrameData));
    memset(FileHeader,0xFF,sizeof(FileHeader));
    memset(FrameHeader,0xFF,sizeof(FrameHeader));

    //fp = fopen("bell_206.gif","rb");
    fp = fopen("slammer.pcap","rb");
    //fp = fopen("test.cap","rb");
    //fp = fopen("test.txt","rb");
    if(fp > 0)
    {
        //FlagFileOpen =1;
        printf("FILE OPEN SUCCESSFUL!!!!!With Handler:%d\n",fp);

        //NOW, READ THE COMPLETE FILE CONTENT TO A LOCAL VARIABLE

        fseek(fp,0,SEEK_SET);

        for(i =0;i<FileHeaderLength;i++)
        {
            FileHeader[i] = fgetc(fp);
        }



        if(CheckMagicNumber() == 1)
        {
            //if((FlagLittleEndian == 1) || (FlagBigEndian == 1) )

            printf("THIS IS VALID PCAP FILE!!!!!\n");

            CheckVersionNumber();

            if(CheckFileLength() == 1)
            {
                printf("The FileSize is: %d\n",FileLength);

                CheckLinkLayerProtocol();

                if(Frame_Protocol==ETHERNET)
                {
                    printf("The Frame Protocol: %x \n",Frame_Protocol);

                    for(i=0;i<FrameHeaderLength;i++)
                    {
                        FrameHeader[i] = fgetc(fp);
                    }

                    do
                    {
                        if(CheckFrameLength() == 1)
                        {
                            if(FrameLength1 >= FrameLength2)
                                FrameLength = FrameLength1;
                            else
                                FrameLength = FrameLength2;

                            for(i=0;i<FrameLength;i++)
                            {
                                FrameData[i] = fgetc(fp);
                            }

                            //ExtractMACAddress();

                            for(i=0;i<FrameHeaderLength;i++)
                            {
                                FrameHeader[i] = fgetc(fp);
                            }

                            if( (FrameHeader[0]==0xFF) && (FrameHeader[1]==0xFF) && (FrameHeader[2]==0xFF) && (FrameHeader[3]==0xFF) )
                            {
                                //printf("\nFILE ENDED\n");
                                ch = 0xFF;
                            }
                        }
                        else
                        {
                            printf("Frame Length is more than 65537...Exiting\n");
                            return 0;
                        }
                    }while(ch!=0xFF);

                    printf("FILE ENDED with 0xFF \n");
                }//End of if for ETHERNET
            }
            else
            {
                printf("File Size is more than 65537...Exiting\n");
                return 0;
            }
        }
        else
        {
            printf("Not Valid PCAP/CAP file....Exiting....\n");
            return 0;
        }
    }
    else
    {

        printf("The PCAP File not able to Open\n");
        FlagFileOpen =0;

        return 0;
    }
    printf("!!!!EXITING...GOOD-BYE!!!!!\n");
    return 0;
}
