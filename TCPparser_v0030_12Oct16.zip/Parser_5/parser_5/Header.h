#define MAX_PCAP_FILE_SIZE 65536  //65536 BYTE
#define ETHERNET 0x01

//int ExtractMACAddress();
//int CheckEthernetAddress();
int CheckFileLength();
int CheckFrameLength();
int CheckLinkLayerProtocol();
int CheckMagicNumber();
int CheckVersionNumber();

int FileHeaderLength = 24;

int FrameHeaderLength = 16;

int FlagFileOpen,FlagMagicNumber;
unsigned char FileHeader[100],FrameHeader[100];
unsigned char MagicNumberLittleEndian[4] = {0xd4,0xc3,0xb2,0xa1};
unsigned char MagicNumberBigEndian[4] = {0xa1,0xb2,0xc3,0xd4};
int FlagBigEndian,FlagLittleEndian;
int MajorVersion,MinorVersion,FileLength;
int FrameLength1,FrameLength2,FrameLength;
int Protocol,Frame_Protocol;
//unsigned char SourceMACAddress[6],DestinationMACAddress[6];
FILE *fp=NULL;
unsigned char FrameData[MAX_PCAP_FILE_SIZE];
