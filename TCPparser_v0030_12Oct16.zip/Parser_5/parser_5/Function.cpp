#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

#define MAX_PCAP_FILE_SIZE 65536  //65536 BYTE
#define MAX_ETHERNET_FRAME_SIZE 1600//1560
#define ETHERNET 0x01

extern int CheckFrameLength(unsigned char* FrameHeader);
extern int CheckLinkLayerProtocol(unsigned char* FileHeader);
extern int CheckMagicNumber(unsigned char* FileHeader);
extern int CheckVersionNumber(unsigned char* FileHeader);

extern int ValidateFileName(int argc, char *argv[]);

//extern unsigned char FileHeader[100],FrameHeader[100];
extern unsigned char MagicNumberLittleEndian[4];
extern unsigned char MagicNumberBigEndian[4];
extern int FlagBigEndian,FlagLittleEndian;
extern unsigned char LibPcapMagicNumberLittleEndian[4];
extern unsigned char LibPcapMagicNumberBigEndian[4];
extern int FlagLibPcapFile;

//extern int MajorVersion,MinorVersion,FileLength;
//extern int FrameLength1,FrameLength2;//,FrameLength;
//extern int Protocol,Frame_Protocol;
extern unsigned char SourceMACAddress[6],DestinationMACAddress[6];

/*int ProcessFrame(unsigned char *Frame_Data,int Frame_Length)
{
    struct ip *ip;
    struct TCP_hdr *tcp;
    unsigned int IP_header_length;
    printf("\nProcessing Frame\n");

    if(Frame_Length < sizeof(struct ether_header)){
        printf("\n Packet size is lessthan Ethernet Header");
        return 0;
    }
    // Skipping Ethernet Header
    Frame_Data +=sizeof(struct ether_header);
    Frame_Length -=sizeof(struct ether_header);

    if(Frame_Length < sizeof(struct ip)){
        printf("\n Packet size is less than IP Header");
        return 0;
    }
    ip= (struct ip*) Frame_Data;  // IP pointer
    IP_header_length = ip->ip_hl * 4;

    if(Frame_Length < IP_header_length){
        printf("\n IP Header is not captured with options");
        return 0;
    }
    if(ip->ip_p != IPPROTO_TCP){
        printf("\n This is non TCP Packet\n");
        return 0;
    }
    // Skipping IP Header to TCP Header
    Frame_Data +=IP_header_length;
    Frame_Length -= IP_header_length;

    if(Frame_Length < sizeof(struct TCP_hdr)){
        printf("\n Packet size is less than TCP Header\n");
        return 0;
    }
    tcp=(struct TCP_hdr*) Frame_Data;
    printf("TCP src_port=%d dst_port=%d \n",
           ntohs(tcp->th_sport),
           ntohs(tcp->th_dport));
    return 1;
}*/

/*int ExtractMACAddress()
{
    int i;

    for(i=0;i<6;i++)
    {
        SourceMACAddress[i] = FrameData[i];
    }

    for(i=0;i<6;i++)
    {
        DestinationMACAddress[i] = FrameData[i+6];
    }

    printf("SourceMACAddress: %02x:%02x:%02x:%02x:%02x:%02x \n",SourceMACAddress[0],
            SourceMACAddress[1],SourceMACAddress[2],SourceMACAddress[3],
            SourceMACAddress[4],SourceMACAddress[5]);

    printf("DestinationMACAddress: %02x:%02x:%02x:%02x:%02x:%02x \n",DestinationMACAddress[0],
            DestinationMACAddress[1],DestinationMACAddress[2],DestinationMACAddress[3],
            DestinationMACAddress[4],DestinationMACAddress[5]);

    return 0;
}*/

/*int CheckEthernetAddress()
{
    int i,j;

    j=40;

    for(i=0;i<6;i++)
    {
        SourceMACAddress[i] = FileHeader[j];
    }

    for(i=0;i<6;i++)
    {
        DestinationMACAddress[i] = FileHeader[j];
    }

    return 0;
}*/

int CheckFrameLength(unsigned char* FrameHeader)
{
    int i,FrameLength,FrameLength1,FrameLength2;

    i = 8;

    //printf("[%d]%x [%d]%x [%d]%x [%d]%x",i,FrameHeader[i],i+1,FrameHeader[i+1],i+1+1,FrameHeader[i+1+1],i+3,FrameHeader[i+3]);

    if(FlagBigEndian == 1)
    {
        FrameLength1 = FrameHeader[i+3] + (FrameHeader[i+2] << 8) + (FrameHeader[i+1] << 16) + (FrameHeader[i] << 24);
        printf("FrameLength1: %d \n",FrameLength1);
        //printf("FrameLength1: %x %d \n",FrameLength1,FrameLength1);
    }

    if(FlagLittleEndian == 1)
    {
        FrameLength1 = FrameHeader[i] + (FrameHeader[i+1] << 8) + (FrameHeader[i+1+1] << 16) + (FrameHeader[i+1+1+1] << 24);
        printf("FrameLength1: %d \n",FrameLength1);
        //printf("FrameLength1: %x %d \n",FrameLength1,FrameLength1);
    }

    i = 8 + 4;
    if(FlagBigEndian == 1)
    {
        FrameLength1 = FrameHeader[i+3] + (FrameHeader[i+2] << 8) + (FrameHeader[i+1] << 16) + (FrameHeader[i] << 24);
        printf("FrameLength2: %d \n",FrameLength2);
        //printf("FrameLength2: %x %d \n",FrameLength2,FrameLength2);
    }

    if(FlagLittleEndian == 1)
    {
        FrameLength2 = FrameHeader[i] + (FrameHeader[i+1] << 8) + (FrameHeader[i+2] << 16) + (FrameHeader[i+3] << 24);
        printf("FrameLength2: %d \n",FrameLength2);
        //printf("FrameLength2: %x %d \n",FrameLength2,FrameLength2);
    }

    if(FrameLength1 >= FrameLength2)
        FrameLength = FrameLength1;
    else
        FrameLength = FrameLength2;

    if(FrameLength >= MAX_ETHERNET_FRAME_SIZE)
        return 0;
    else
        return FrameLength;
}

int CheckLinkLayerProtocol(unsigned char* FileHeader)
{
    int i,Protocol;

    i=20;

    if(FlagLittleEndian==1)
    {
        Protocol = FileHeader[i] + (FileHeader[i+1] << 8) + (FileHeader[i+2] << 16) + (FileHeader[i+3] << 24);
        //if(Protocol == ETHERNET)
          //  Frame_Protocol = ETHERNET;
    }
    if(FlagBigEndian==1)
    {
        Protocol = FileHeader[i+3] + (FileHeader[i+2] << 8) + (FileHeader[i+1] << 16) + (FileHeader[i] << 24);
        //if(Protocol == ETHERNET)
          //  Frame_Protocol = ETHERNET;
    }
    return Protocol;
}

/*int CheckFileLength(unsigned char* FileHeader)
{
    int i;

    i = 16;

    if(FlagLittleEndian == 1)
    {
        FileLength = FileHeader[i] + (FileHeader[i+1] << 8) + (FileHeader[i+1+1] << 16) + (FileHeader[i+1+1+1] << 24);
        //printf("FileLength: %x %d \n",FileLength);
    }

    if(FlagBigEndian == 1)
    {
        FileLength = FileHeader[i] + FileHeader[i+1] + FileHeader[i+1+1] + FileHeader[i+2+1];
    }

    if(FileLength >= MAX_PCAP_FILE_SIZE)
        return 0;
    else
        return 1;
}*/

int CheckVersionNumber(unsigned char* FileHeader)
{
    int i;
    int MajorVersion,MinorVersion;

    i =4;

    if(FlagLittleEndian == 1)
    {
        MajorVersion = FileHeader[i] + (FileHeader[i+1] << 8);
        MinorVersion = FileHeader[i+1+1] + (FileHeader[i+1+1+1] << 8);
    }

    printf("MajorVersion: %x MinorVersion:%x \n",MajorVersion,MinorVersion);

    if(FlagBigEndian == 1)
    {
        MajorVersion = FileHeader[i+1] + (FileHeader[i] << 8);
        MinorVersion = FileHeader[i+1+1+1] + (FileHeader[i+1+1] << 8);
    }
    return 0;
}

int CheckMagicNumber(unsigned char* FileHeader)
{
    int i;

    FlagLittleEndian=1;
    FlagLibPcapFile=2;

    printf("Checking For Little Endian\n");

    for(i=0;i<4;i++)
    {
        if(MagicNumberLittleEndian[i] != FileHeader[i])
        {
            printf("NOT Little Endian \n");
            FlagLittleEndian=0;
            FlagLibPcapFile=0;
            break;
        }
    }

    if(FlagLittleEndian == 0)
    {
        printf("Checking For BIG ENDIAN \n");

        FlagBigEndian = 1;
        FlagLibPcapFile=2;

        for(i=0;i<4;i++)
        {
            if(MagicNumberBigEndian[i] != FileHeader[i])
            {
                printf("NOT Big Endian\n");
                FlagBigEndian = 0;
                FlagLibPcapFile=0;
                break;
            }
        }
    }

    if((FlagLittleEndian == 0) && (FlagBigEndian == 0) )
    {
        printf(" Checking for LIB-PCAP FILE....\n");

        FlagLittleEndian=1;

        FlagLibPcapFile=1;

        printf("Checking For Little Endian\n");

        for(i=0;i<4;i++)
        {
            if(LibPcapMagicNumberLittleEndian[i] != FileHeader[i])
            {
                printf("NOT Little Endian \n");
                FlagLittleEndian=0;
                FlagLibPcapFile=0;
                break;
            }
        }

        if(FlagLittleEndian == 0)
        {
            printf("Checking For BIG ENDIAN \n");

            FlagBigEndian = 1;

            FlagLibPcapFile=1;

            for(i=0;i<4;i++)
            {
                if(LibPcapMagicNumberBigEndian[i] != FileHeader[i])
                {
                    printf("NOT Big Endian\n");
                    FlagBigEndian = 0;
                    FlagLibPcapFile=0;
                    break;
                }
            }
        }
    }


    if((FlagLittleEndian == 1) || (FlagBigEndian == 1) )
    {
        //printf("IT IS VALID PCAP\n");

        if(FlagLittleEndian == 1)
        {
            printf("It is Little Endian\n");
            FlagBigEndian=0;
            return 1;
        }
        else
        {
            printf("It is Big Endian\n");
            FlagLittleEndian=0;
            return 1;
        }
    }
    else
    {
        printf("NOT VALID PCAP FILE\n");
        return 0;
    }
}



//########################################################
//Functions by Surendra Sharma
//**********************************************************





extern void
print_hex_ascii_line(const u_char *payload, int len, int offset)
{

    int i;
    int gap;
    const u_char *ch;

    /* offset */
    printf("%05d   ", offset);

    /* hex */
    ch = payload;
    for(i = 0; i < len; i++) {
        printf("%02x ", *ch);
        ch++;
        /* print extra space after 8th byte for visual aid */
        if (i == 7)
            printf(" ");
    }
    /* print space to handle line less than 8 bytes */
    if (len < 8)
        printf(" ");

    /* fill hex gap with spaces if not full line */
    if (len < 16) {
        gap = 16 - len;
        for (i = 0; i < gap; i++) {
            printf("   ");
        }
    }
    printf("   ");

    /* ascii (if printable) */
    ch = payload;
    for(i = 0; i < len; i++) {
        if (isprint(*ch))
            printf("%c", *ch);
        else
            printf(".");
        ch++;
    }

    printf("\n");

return;
}

/*
 * print packet payload data (avoid printing binary data)
 */
extern void
print_payload(const u_char *payload, int len)
{

    int len_rem = len;
    int line_width = 16;			/* number of bytes per line */
    int line_len;
    int offset = 0;					/* zero-based offset counter */
    const u_char *ch = payload;

    if (len <= 0)
        return;

    /* data fits on one line */
    if (len <= line_width) {
        print_hex_ascii_line(ch, len, offset);
        return;
    }

    /* data spans multiple lines */
    for ( ;; ) {
        /* compute current line length */
        line_len = line_width % len_rem;
        /* print line */
        print_hex_ascii_line(ch, line_len, offset);
        /* compute total remaining */
        len_rem = len_rem - line_len;
        /* shift pointer to remaining bytes to print */
        ch = ch + line_len;
        /* add offset */
        offset = offset + line_width;
        /* check if we have line width chars or less */
        if (len_rem <= line_width) {
            /* print last line and get out */
            print_hex_ascii_line(ch, len_rem, offset);
            break;
        }
    }

return;
}





//************************************File Name Validation************************************

//To skip the Programm Name

 int ValidateFileName(int argc, char *argv[])
 {
     int i,special_flag,arglen;

     int arg_max_length=20;


    ++argv;--argc;

    // No.of command line arguments checking and restricting to only one argument.
    if(argc < 1)
    {
        printf("\n Programm Requires one Argument (Eneter input PCAP file name)..!!\n");
        return 0;
    }
    else if(argc>1){
        printf("\n Too many Arguments, Programme Accepts only one Argument. Bye!!\n");
        return 0;
    }
    else{
            arglen=strlen(argv[0]);

        //File name length checking.
        if(arglen >=arg_max_length){
            printf("\n File name is too big, Don't try to crash our programme!!!\n");
            return 0;
        }

        //Special character checking in file name.
        special_flag=0;
        for(i=0;i<arglen;i++){
            //printf("\n%c",argv[0][i]);
            switch(argv[0][i])
            {
                case '\\':  printf("\n Back slash is detected, It is not allowed in File-name.\n");
                            special_flag=1;
                            break;
                case '*':   printf("\n Star symbol is detected, It is not allowed in File-name.\n");
                            special_flag=1;
                            break;
                case '\'':  printf("\n single quote is detected, It is not allowed in File-name.\n");
                            special_flag=1;
                            break;
                case '"':   printf("\n Double quote is detected, It is not allowed in File-name.\n");
                            special_flag=1;
                            break;
                case ' ':   printf("\n Space is detected, It is not allowed in File-name.\n");
                            special_flag=1;
                            break;

                // we can add more speical characters here, if any.
            }
            if(special_flag==1){
                printf("\n Special characters are not allowed, Don't try to crash our programme!!!\n");
                return 0;
            }
        }
        printf("\n File Name is Proper and Accepted\n");
         return 1;
    }
 }
