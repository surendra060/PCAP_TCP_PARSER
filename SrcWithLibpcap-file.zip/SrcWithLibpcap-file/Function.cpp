#include <stdio.h>

#define MAX_PCAP_FILE_SIZE 65536  //65536 BYTE
#define ETHERNET 0x01

//extern int CheckFileLength();
extern int CheckFrameLength();
extern int CheckLinkLayerProtocol();
extern int CheckMagicNumber();
extern int CheckVersionNumber();

extern unsigned char FileHeader[100],FrameHeader[100];
extern unsigned char MagicNumberLittleEndian[4];
extern unsigned char MagicNumberBigEndian[4];
extern unsigned char LibPcapMagicNumberLittleEndian[4];
extern unsigned char LibPcapMagicNumberBigEndian[4];
extern int FlagLibPcapFile;
extern int FlagBigEndian,FlagLittleEndian;
extern int MajorVersion,MinorVersion;//,FileLength;
extern int FrameLength1,FrameLength2,FrameLength;
extern int Protocol,Frame_Protocol;
extern unsigned char SourceMACAddress[6],DestinationMACAddress[6];

int CheckFrameLength()
{
    int i;

    i = 8;

    //printf("[%d]%x [%d]%x [%d]%x [%d]%x",i,FrameHeader[i],i+1,FrameHeader[i+1],i+1+1,FrameHeader[i+1+1],i+3,FrameHeader[i+3]);

    if(FlagBigEndian == 1)
    {
        FrameLength1 = FrameHeader[i+3] + (FrameHeader[i+2] << 8) + (FrameHeader[i+1] << 16) + (FrameHeader[i] << 24);
        printf("FrameLength1: %d \n",FrameLength1);
        //printf("FrameLength1: %x %d \n",FrameLength1,FrameLength1);
    }

    if(FlagLittleEndian == 1)
    {
        FrameLength1 = FrameHeader[i] + (FrameHeader[i+1] << 8) + (FrameHeader[i+1+1] << 16) + (FrameHeader[i+1+1+1] << 24);
        printf("FrameLength1: %d \n",FrameLength1);
        //printf("FrameLength1: %x %d \n",FrameLength1,FrameLength1);
    }


    i = 8 + 4;
    if(FlagBigEndian == 1)
    {
        FrameLength1 = FrameHeader[i+3] + (FrameHeader[i+2] << 8) + (FrameHeader[i+1] << 16) + (FrameHeader[i] << 24);
        printf("FrameLength2: %d \n",FrameLength2);
        //printf("FrameLength2: %x %d \n",FrameLength2,FrameLength2);
    }

    if(FlagLittleEndian == 1)
    {
        FrameLength2 = FrameHeader[i] + (FrameHeader[i+1] << 8) + (FrameHeader[i+2] << 16) + (FrameHeader[i+3] << 24);
        printf("FrameLength2: %d \n",FrameLength2);
        //printf("FrameLength2: %x %d \n",FrameLength2,FrameLength2);
    }

    if(FrameLength1 >= MAX_PCAP_FILE_SIZE)
        return 0;
    else
    {
        if(FrameLength2 >= MAX_PCAP_FILE_SIZE)
            return 0;
        else
            return 1;
    }
}

int CheckLinkLayerProtocol()
{
    int i;

    i=20;

    if(FlagLittleEndian==1)
    {
        Protocol = FileHeader[i] + (FileHeader[i+1] << 8) + (FileHeader[i+2] << 16) + (FileHeader[i+3] << 24);
        if(Protocol == ETHERNET)
            Frame_Protocol = ETHERNET;
    }
    if(FlagBigEndian==1)
    {
        Protocol = FileHeader[i+3] + (FileHeader[i+2] << 8) + (FileHeader[i+1] << 16) + (FileHeader[i] << 24);
        if(Protocol == ETHERNET)
            Frame_Protocol = ETHERNET;
    }
    return 0;
}

/*int CheckFileLength()
{
    int i;

    i = 16;

    if(FlagLittleEndian == 1)
    {
        FileLength = FileHeader[i] + (FileHeader[i+1] << 8) + (FileHeader[i+1+1] << 16) + (FileHeader[i+1+1+1] << 24);
        //printf("FileLength: %x %d \n",FileLength);
    }

    if(FlagBigEndian == 1)
    {
        FileLength = FileHeader[i] + FileHeader[i+1] + FileHeader[i+1+1] + FileHeader[i+2+1];
    }

    return 1;
    //if(FileLength >= MAX_PCAP_FILE_SIZE)
    //    return 0;
    //else
    //    return 1;
}*/

int CheckVersionNumber()
{
    int i;

    i =4;

    if(FlagLittleEndian == 1)
    {
        MajorVersion = FileHeader[i] + (FileHeader[i+1] << 8);
        MinorVersion = FileHeader[i+1+1] + (FileHeader[i+1+1+1] << 8);
    }

    printf("MajorVersion: %x MinorVersion:%x \n",MajorVersion,MinorVersion);

    if(FlagBigEndian == 1)
    {
        MajorVersion = FileHeader[i+1] + (FileHeader[i] << 8);
        MinorVersion = FileHeader[i+1+1+1] + (FileHeader[i+1+1] << 8);
    }
    return 0;
}

int CheckMagicNumber()
{
    int i;

    FlagLittleEndian=1;
    FlagLibPcapFile=2;

    printf("Checking For Little Endian\n");   

    for(i=0;i<4;i++)
    {
        if(MagicNumberLittleEndian[i] != FileHeader[i])
        {
            printf("NOT Little Endian \n");
            FlagLittleEndian=0;
            FlagLibPcapFile=0;
            break;
        }
    }

    if(FlagLittleEndian == 0)
    {
        printf("Checking For BIG ENDIAN \n");

        FlagBigEndian = 1;
        FlagLibPcapFile=2;

        for(i=0;i<4;i++)
        {
            if(MagicNumberBigEndian[i] != FileHeader[i])
            {
                printf("NOT Big Endian\n");
                FlagBigEndian = 0;
                FlagLibPcapFile=0;
                break;
            }
        }
    }

    if((FlagLittleEndian == 0) && (FlagBigEndian == 0) )
    {
        printf(" Checking for LIB-PCAP FILE....\n");

        FlagLittleEndian=1;

        FlagLibPcapFile=1;

        printf("Checking For Little Endian\n");

        for(i=0;i<4;i++)
        {
            if(LibPcapMagicNumberLittleEndian[i] != FileHeader[i])
            {
                printf("NOT Little Endian \n");
                FlagLittleEndian=0;
                FlagLibPcapFile=0;
                break;
            }
        }

        if(FlagLittleEndian == 0)
        {
            printf("Checking For BIG ENDIAN \n");

            FlagBigEndian = 1;

            FlagLibPcapFile=1;

            for(i=0;i<4;i++)
            {
                if(LibPcapMagicNumberBigEndian[i] != FileHeader[i])
                {
                    printf("NOT Big Endian\n");
                    FlagBigEndian = 0;
                    FlagLibPcapFile=0;
                    break;
                }
            }
        }
    }


    if((FlagLittleEndian == 1) || (FlagBigEndian == 1) )
    {
        //printf("IT IS VALID PCAP\n");

        if(FlagLittleEndian == 1)
        {
            printf("It is Little Endian\n");
            FlagBigEndian=0;
            return 1;
        }
        else
        {
            printf("It is Big Endian\n");
            FlagLittleEndian=0;
            return 1;
        }
    }
    else
    {
        printf("NOT VALID PCAP FILE\n");
        return 0;
    }
}
