1. The TCP parser is a program to parse the Network packets from Stored PCAP file. The project has been developed in QTCretor. The entire project is in two folders (Src and Build) with the executale and input / output files in Build Folder. Both folders along with Presentation are zipped alongwith this Readme text file.

2. The program expects exacly one argument as input file of type PCAP. The data is parsed and result is shown on STd out as well as the result is stored in parserdata.txt in the same file.

3. The usage of the program is  ./TCPparser <inputfile.pcap>

4. The folder comprises of several test input file including a few fuzzed files

Eg input for an input file test.cap is as follows
./TCPparser test.cap

5. The program ends with the following summary of output 

****** SUMMARY OF PARSER DATA test.cap*************

 TotalFrame=4 	 FrameEscape= 0 	 Total ErrorFrameCounter = 0
 Total Frames Analysed = 4
 Total valid IP Packets Processed = 4 	 Total Invalid IP datagrams = 0 
 Valid TCP Segments Processed= 4 	 Total NonTCP Segments= 0 	Total BadTCPSegment = 0 

6. The summary of results obtained for different variety of files tested and present in the folder is reproduced below. The Detailed result of parsing is stored in parserdata.txtwhich is also stored in the same folder.

****** SUMMARY OF PARSER DATA   testFile-2.pcap *************

 TotalFrame=45605 	 FrameEscape= 8 	 Total ErrorFrameCounter = 19
 Total Frames Analysed = 45578
 Total valid IP Packets Processed = 45578 	Total Invalid IP datagrams = 19 
 Valid TCP Segments Processed= 44013 	 	Total NonTCP Segments= 1565 	Total BadTCPSegment = 0 

****** SUMMARY OF PARSER DATA testFile-1.pcap *************

 TotalFrame=6306 	 FrameEscape= 0 	 Total ErrorFrameCounter = 7
 Total Frames Analysed = 6299
 Total valid IP Packets Processed = 6299 	 Total Invalid IP datagrams = 7 
 Valid TCP Segments Processed= 6012 	 Total NonTCP Segments= 287 	Total BadTCPSegment = 0 

****** SUMMARY OF PARSER DATA slammer.pcap*************

 TotalFrame=1 	 FrameEscape= 0 	 Total ErrorFrameCounter = 0
 Total Frames Analysed = 1
 Total valid IP Packets Processed = 1 	 Total Invalid IP datagrams = 0 
 Valid TCP Segments Processed= 0 	 Total NonTCP Segments= 1 	Total BadTCPSegment = 0 

****** SUMMARY OF PARSER DATA test.cap*************

 TotalFrame=4 	 FrameEscape= 0 	 Total ErrorFrameCounter = 0
 Total Frames Analysed = 4
 Total valid IP Packets Processed = 4 	 Total Invalid IP datagrams = 0 
 Valid TCP Segments Processed= 4 	 Total NonTCP Segments= 0 	Total BadTCPSegment = 0 


****** SUMMARY OF PARSER DATA (Data FUzzed )FuzOflwFile-1.pcap*************

 TotalFrame=6306 	 FrameEscape= 0 	 Total ErrorFrameCounter = 7
 Total Frames Analysed = 6299
 Total valid IP Packets Processed = 6299 	 Total Invalid IP datagrams = 7 
 Valid TCP Segments Processed= 6012 	 Total NonTCP Segments= 287 	Total BadTCPSegment = 0 











