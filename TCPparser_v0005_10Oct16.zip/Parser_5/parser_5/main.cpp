#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include<sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>

#define MAX_PCAP_FILE_SIZE 65536  //65536 BYTE
#define ETHERNET 0x01
/* default snap length (maximum bytes per packet to capture) */
#define SNAP_LEN 1518

/* ethernet headers are always exactly 14 bytes [1] */
#define SIZE_ETHERNET 14

/* Ethernet addresses are 6 bytes */
//#define ETHER_ADDR_LEN	6

//int ExtractMACAddress();
//int CheckEthernetAddress();
int CheckFileLength();
int CheckFrameLength();
int CheckLinkLayerProtocol();
int CheckMagicNumber();
int CheckVersionNumber();

void print_hex_ascii_line(const u_char *payload, int len, int offset);
void print_payload(const u_char *payload, int len);

//int ProcessFrame(unsigned char,int);

/* Ethernet header */
struct sniff_ethernet {
        u_char  ether_dhost[ETHER_ADDR_LEN];    /* destination host address */
        u_char  ether_shost[ETHER_ADDR_LEN];    /* source host address */
        u_short ether_type;                     /* IP? ARP? RARP? etc */
};

/* IP header */
struct IP_hdr {
        u_char  ip_vhl;                 /* version << 4 | header length >> 2 */
        u_char  ip_tos;                 /* type of service */
        u_short ip_len;                 /* total length */
        u_short ip_id;                  /* identification */
        u_short ip_off;                 /* fragment offset field */
        #define IP_RF 0x8000            /* reserved fragment flag */
        #define IP_DF 0x4000            /* dont fragment flag */
        #define IP_MF 0x2000            /* more fragments flag */
        #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
        u_char  ip_ttl;                 /* time to live */
        u_char  ip_p;                   /* protocol */
        u_short ip_sum;                 /* checksum */
        struct  in_addr ip_src,ip_dst;  /* source and dest address */
};
#define IP_HL(ip)               (((ip)->hl) & 0x0f)
#define IP_V(ip)                (((ip)->ip_vhl) >> 4)



// TCP Header
typedef u_int tcp_seq;

struct TCP_hdr{
    u_short th_sport;
    u_short th_dport;
    tcp_seq th_seq;
    tcp_seq th_ack;
    u_char th_offx2;
#define TH_OFF(th)  (((th)->th_offx2 & 0xf0) >> 4)
    u_char th_flags;
#define TH_FIN 0x01
#define TH_SYN 0x02
#define TH_RST 0x04
#define TH_PUSH 0x08
#define TH_ACK 0x10
#define TH_URG 0x20
#define TH_ECE 0x40
#define TH_CWR 0x80
#define TH_FLAGS    (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
    u_short th_win;
    u_short th_sum;
    u_short th_urp;
};

int FileHeaderLength = 24;

int FrameHeaderLength = 16;

int FlagFileOpen,FlagMagicNumber;
unsigned char FileHeader[100],FrameHeader[100];
unsigned char MagicNumberLittleEndian[4] = {0xd4,0xc3,0xb2,0xa1};
unsigned char MagicNumberBigEndian[4] = {0xa1,0xb2,0xc3,0xd4};
int FlagBigEndian,FlagLittleEndian;
int MajorVersion,MinorVersion,FileLength;
int FrameLength1,FrameLength2,FrameLength;
int Protocol,Frame_Protocol;
//unsigned char SourceMACAddress[6],DestinationMACAddress[6];
FILE *fp=NULL;

unsigned char FrameData[MAX_PCAP_FILE_SIZE];

int Extract_Eth_header(struct ether_header  *Eth_hdr, unsigned int total_frame_len){

    //struct ether_header Eth_Hdr = FrameData;
    //if ()
    printf("\n**** Processing Ethernet Frame Header ********\n");

    printf("Eth_Header %x", Eth_hdr);
    printf("Destinantion MAC Address : %02X:%02X:%02X:%02X:%02X:%02X\n", Eth_hdr->ether_dhost[0],Eth_hdr->ether_dhost[1], \
            Eth_hdr->ether_dhost[2],Eth_hdr->ether_dhost[3],Eth_hdr->ether_dhost[4],Eth_hdr->ether_dhost[5]);

    printf("Source MAC Address : %02X:%02X:%02X:%02X:%02X:%02X\n", Eth_hdr->ether_shost[0],Eth_hdr->ether_shost[1], \
            Eth_hdr->ether_shost[2],Eth_hdr->ether_shost[3],Eth_hdr->ether_shost[4],Eth_hdr->ether_shost[5]);

    printf("Next Header/Protocol Type: %04hx\n", ntohs(Eth_hdr->ether_type));
   // printf("Next Header/Protocol Type: %04hx\n", ntohs(Eth_hdr->ether));


}

int Extract_IPdata(struct ip *ip, int IP_header_len){
    unsigned int TCP_pack_len;
    int size_ip = (ip->ip_len)*4;
        if (size_ip < 20) {
            printf("   * Invalid IP header length: %u bytes\n", size_ip);
            return -1;
        }
        else {

       unsigned int IP_pack_len = ntohs(ip->ip_len);

        printf("\n **** Processing IP Header*****\n");

        printf("IP Ver : %u\t", ip->ip_v);
        printf("IP header Length : %u bytes\n", (ip->ip_hl)*4);
        printf("Type of Service : %u\n", ntohs(ip->ip_tos));
        printf("IP Packet Length : %u\n", ntohs(ip->ip_len));


        printf("IP Fragment Identifier : %u\n", ntohs(ip->ip_id));
        printf("IP Fragment Offset(if present) : %u\n", ntohs(ip->ip_off));

        printf("Next Protocol ID : %u\n", ntohs(ip->ip_p));
        printf("TTL : %u\n", ntohs(ip->ip_ttl));
        printf("Source IP : %s\n", inet_ntoa(ip->ip_src));
        printf("Destination IP : %s\n", inet_ntoa(ip->ip_dst));
        unsigned short chksum = ip->ip_sum;

        printf("IP Header Checksum : %u\n", chksum);

        TCP_pack_len = IP_pack_len - ((ip->ip_hl)*4);
        return TCP_pack_len;

      }

}

int Extract_TCPdata(struct TCP_hdr* tcp, unsigned int TCP_pack_len){

    printf("\n **** Processing TCP Header*****\n");

        int size_tcp = TH_OFF(tcp)*4;
        if ((size_tcp < 20) || (size_tcp > 32)) {
            printf("   * Invalid TCP header length: %u bytes\n", size_tcp);
            return -1;
            } else if ((size_tcp<=32) && (size_tcp >=20))
                    {
                    printf("   TCP Header Size(Bytes) = %d\n", size_tcp);

                    printf("   Src port : %d\n", ntohs(tcp->th_sport));
                    printf("   Dst port : %d\n", ntohs(tcp->th_dport));
                    printf("   Sequence Number : %u\n", ntohs(tcp->th_seq));
                    printf("   Acknowledgement Number : %u\n", ntohs(tcp->th_ack));
                    printf("   TCP Data Offset : %d\n",size_tcp);
                    printf("   Flags : %u \t flagSize = %lu \n",tcp->th_flags, sizeof(tcp->th_flags));

                    printf("   TCP Window Size : %u\n", ntohs(tcp->th_win));
                    printf("   Checksum : %u\n", ntohs(tcp->th_sum));
                    printf("   Urgent Field value : %u\n", ntohs(tcp->th_urp));


                    /* define/compute tcp payload (segment) offset */
                    unsigned char* payload;

                    payload = (u_char *)(tcp + size_tcp);

                    /* compute tcp payload (segment) size */
                    int size_payload;
                    size_payload =  (TCP_pack_len - size_tcp);
                    printf("   App Payload Size %u\n", size_payload);

                    /*
                     * Print payload data; it might be binary, so don't just
                     * treat it as a string.
                     */
                    if (size_payload > 0) {
                    printf("   Payload (%d bytes):\n", size_payload);
                    print_payload(payload,size_payload);

                 }


        }
}





int ProcessFrame(unsigned char *Frame_Data,int Frame_Length)
{
    struct ether_header *Eth_hdr;
    struct ip *ip;
    struct TCP_hdr *tcp;
    unsigned int TCP_pack_len = 0;

    unsigned int IP_header_length;
    int total_frame_len  = Frame_Length;
    printf("\nProcessing Frame\n");

    if(Frame_Length < sizeof(struct ether_header)){
        printf("\n Packet size is less than Ethernet Header");
        return 0;
    }
    printf("Frame_Header %x", Frame_Data);

    Eth_hdr = (struct ether_header*) Frame_Data;
    Extract_Eth_header(Eth_hdr, total_frame_len);

    // Skipping Ethernet Header
    Frame_Data +=sizeof(struct ether_header);
    Frame_Length -=sizeof(struct ether_header);

    if(Frame_Length < sizeof(struct ip)){
        printf("\n Packet size is less than IP Header");
        return 0;
    }
    ip = (struct ip*) Frame_Data;  // IP pointer
    IP_header_length = (ip->ip_hl) * 4;


    if(Frame_Length < IP_header_length){
        printf("\n IP Header is not captured with options");
        return 0;

    }

    else {

           TCP_pack_len = Extract_IPdata(ip,IP_header_length);
           printf("\TCP_pack_Len = %u\n",TCP_pack_len);

    }

        if(ip->ip_p != IPPROTO_TCP){
            printf("\n This is non TCP Packet\n");
            return 0;
        }
        // Skipping IP Header to TCP Header
        Frame_Data +=IP_header_length;
        Frame_Length -= IP_header_length;

        if(Frame_Length < sizeof(struct TCP_hdr)){
            printf("\n Packet size is less than TCP Header\n");
            return 0;
        }
        tcp=(struct TCP_hdr*) Frame_Data;

        Extract_TCPdata(tcp, TCP_pack_len);

        //printf("TCP src_port=%d dst_port=%d \n",
         //      ntohs(tcp->th_sport),
         //      ntohs(tcp->th_dport));
        return 1;
}




int main(int argc, char *argv[])
{
    int i;
    unsigned char ch;

    memset(FrameData,0x00,sizeof(FrameData));
    memset(FileHeader,0x00,sizeof(FileHeader));
    memset(FrameHeader,0x00,sizeof(FrameHeader));

    //fp = fopen("bell_206.gif","rb");
    //fp = fopen("slammer.pcap","rb");
    //fp = fopen("WS-Lib-pcap.pcap","rb");
    //fp = fopen("WS-tcp-dump.pcap","rb");


    fp = fopen("test.cap","rb");

    FILE* fdata;
    fdata=NULL;
    fdata = fopen("parserdata.txt","w+");
    if (fdata==NULL){

      printf("file to write not found");
      exit(1);
    }

    //fp = fopen("test.txt","rb");
    if(fp > 0)
    {
        //FlagFileOpen =1;
        printf("FILE OPEN SUCCESSFUL!!!!!With Handler:%d\n",fp);

        //NOW, READ THE COMPLETE FILE CONTENT TO A LOCAL VARIABLE

        fseek(fp,0,SEEK_SET);

        for(i =0;i<FileHeaderLength;i++)
        {
            FileHeader[i] = fgetc(fp);
        }

        if(CheckMagicNumber() == 1)
        {
            //if((FlagLittleEndian == 1) || (FlagBigEndian == 1) )

            printf("THIS IS VALID PCAP FILE!!!!!\n");

            CheckVersionNumber();

            if(CheckFileLength() == 1)
            {
                printf("The FileSize is: %d\n",FileLength);

                CheckLinkLayerProtocol();

                if(Frame_Protocol==ETHERNET)
                {
                    printf("The Frame Protocol: %x \n",Frame_Protocol);

                    for(i=0;i<FrameHeaderLength;i++)
                    {
                        FrameHeader[i] = fgetc(fp);
                    }

                    do
                    {
                        if(CheckFrameLength() == 1)
                        {
                            if(FrameLength1 >= FrameLength2)
                                FrameLength = FrameLength1;
                            else
                                FrameLength = FrameLength2;

                            for(i=0;i<FrameLength;i++)
                            {
                                FrameData[i] = fgetc(fp);
                            }

                            //ExtractMACAddress();

                            //Ramu's Contribution
                            i = ProcessFrame(FrameData,FrameLength);
                            if(i==1)
                            {
                                printf("\n packet Processed Successfully\n");
                                for(i=0;i<FrameHeaderLength;i++)
                                {
                                    FrameHeader[i] = fgetc(fp);
                                }

                                if( (FrameHeader[0]==0xFF) && (FrameHeader[1]==0xFF) && (FrameHeader[2]==0xFF) && (FrameHeader[3]==0xFF) )
                                {
                                    //printf("\nFILE ENDED\n");
                                    ch = 0xFF;
                                }
                            }
                            else
                            {
                                printf("\n Packet is not processed Successfully\n");
                                ch = 0xFF;
                                printf("\nExiting Because Packet Processing Failed!!!\n");

                            }
                        }
                        else
                        {
                            printf("Frame Length is more than 65537...Exiting\n");
                            return 0;
                        }
                    }while(ch!=0xFF);

                    printf("FILE ENDED with 0xFF \n");
                }//End of if for ETHERNET
            }
            else
            {
                printf("File Size is more than 65537...Exiting\n");
                return 0;
            }
        }
        else
        {
            printf("Not Valid PCAP/CAP file....Exiting....\n");
            return 0;
        }
    }
    else
    {

        printf("The PCAP File not able to Open\n");
        FlagFileOpen =0;

        return 0;
    }
    printf("!!!!EXITING...GOOD-BYE!!!!!\n");

    fclose(fdata);
    return 0;
}
